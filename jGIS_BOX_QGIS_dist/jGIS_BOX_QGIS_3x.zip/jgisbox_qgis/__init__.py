# jGIS BOX for QGIS - plugin entry point.
# This shim stays as plaintext (QGIS must import it); all logic lives in the
# sibling modules, which ship Cython-compiled (.pyd / .so) via build_qgis.bat.


def classFactory(iface):
    from .plugin import JGisBox
    return JGisBox(iface)
